const express = require("express");
const router = express.Router();
const mysql = require("mysql");
const checkAuth = require("../middleware/check-atuh"); // correct the spelling typo from check-atuh to check-auth
const multer = require("multer");
const path = require("path");
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./uploads");
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});

const fileFilter = (req, file, cb) => {
  if (
    file.mimetype === "image/jpeg" ||
    file.mimetype === "image/png" ||
    file.mimetype === "image/jpeg"
  ) {
    cb(null, true);
  } else {
    cb(null, false);
  }
};

const upload = multer({
  storage: storage,
  limits: { fileSize: 1024 * 1024 * 5 },
  fileFilter: fileFilter,
});

// MySQL connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "rsms",
});

db.connect((err) => {
  if (err) {
    console.error("Database connection failed:", err);
    return;
  }
});

// Get unique task standards
router.get("/standards", checkAuth, (req, res) => {
  db.query("SELECT DISTINCT task_standard FROM syllabus", (err, results) => {
    if (err) {
      return res.status(500).json({ error: "Database query failed" });
    }
    res.json({ data: results });
  });
});

// Get unique created_at options
router.get("/created-at-options", checkAuth, (req, res) => {
  db.query("SELECT DISTINCT created_at FROM syllabus", (err, results) => {
    if (err) {
      return res.status(500).json({ error: "Database query failed" });
    }
    res.json({ data: results });
  });
});


// Get tasks based on filtering criteria
router.get("/", checkAuth, (req, res) => {
  const { task_standard, created_at } = req.query;
  
  let query = 'SELECT * FROM syllabus WHERE 1=1';
  const queryParams = [];

  if (task_standard) {
    query += ' AND task_standard = ?';
    queryParams.push(task_standard);
  }
  
  if (created_at) {
    query += ' AND created_at = ?';
    queryParams.push(created_at);
  }

  db.query(query, queryParams, (err, results) => {
    if (err) {
      return res.status(500).json({ error: "Database query failed" });
    }
    res.json({ data: results });
  });
});







module.exports = router;
