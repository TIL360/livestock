const express = require("express");
const router = express.Router();
const mysql = require("mysql");
const checkAuth = require("../middleware/check-atuh"); // correct the spelling typo from check-atuh to check-auth
const multer = require("multer");
const path = require("path");
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./uploads");
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});

const fileFilter = (req, file, cb) => {
  if (
    file.mimetype === "image/jpeg" ||
    file.mimetype === "image/png" ||
    file.mimetype === "image/jpeg"
  ) {
    cb(null, true);
  } else {
    cb(null, false);
  }
};

const upload = multer({
  storage: storage,
  limits: { fileSize: 1024 * 1024 * 5 },
  fileFilter: fileFilter,
});

// MySQL connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "rsms",
});

db.connect((err) => {
  if (err) {
    console.error("Database connection failed:", err);
    return;
  }
});

// Get unique task standards
router.get("/standards", checkAuth, (req, res) => {
  db.query("SELECT DISTINCT task_standard FROM syllabus", (err, results) => {
    if (err) {
      return res.status(500).json({ error: "Database query failed" });
    }
    res.json({ data: results });
  });
});

// Get unique created_at options
// Get unique created_at options
router.get("/created-at-options", checkAuth, (req, res) => {
  db.query("SELECT DISTINCT created_at FROM syllabus", (err, results) => {
    if (err) {
      return res.status(500).json({ error: "Database query failed" });
    }
    // Results will now have the date only in YYYY-MM-DD format as stored in the database
    res.json({ data: results });
  });
});


router.get("/", checkAuth, (req, res) => {
  const { task_standard, created_at } = req.query;

  let query = 'SELECT * FROM syllabus WHERE 1=1';
  const queryParams = [];

  if (task_standard) {
    query += ' AND task_standard = ?';
    queryParams.push(task_standard);
  }

  if (created_at) {
    query += ' AND DATE(created_at) = ?'; // Ensure we're checking just the date portion
    queryParams.push(created_at);
  }

  db.query(query, queryParams, (err, results) => {
    if (err) {
      return res.status(500).json({ error: "Database query failed" });
    }
    // Directly return data as is from database, including created_at
    res.json({ data: results });
  });
});





// Create a new task
// Create a new task
router.post("/new-task", checkAuth, async (req, res) => {
  const { task_standard, subject, task } = req.body;
  console.log(req.body);

  // Get current date in YYYY-MM-DD format
  const now = new Date(); 
  const createdAt = now.toISOString().slice(0, 10); // Format: YYYY-MM-DD

  const query = `
      INSERT INTO syllabus (task_standard, subject, task, created_at) 
      VALUES (?, ?, ?, ?)`; // Adjusted the query to include all fields

  db.query(query, [task_standard, subject, task, createdAt], (error, result) => {
      if (error) {
          console.error("Database query error:", error);
          return res.status(500).json({ error: "Database query failed" });
      }

      res.status(201).json({ success: true, message: "Task created successfully", data: result });
  });
});

// Delete a task by ID
router.delete("/:syllabus_id", checkAuth, (req, res) => {
  const taskId = req.params.syllabus_id; // Here is the issue, you should use req.params.taskid

  const query = "DELETE FROM syllabus WHERE syllabus_id = ?";

  db.query(query, [taskId], (error, result) => {
    if (error) {
      console.error("Error deleting task:", error);
      return res.status(500).json({ error: "Database query failed" });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Task not found" });
    }

    res.status(200).json({ success: true, message: "Task deleted successfully" });
  });
});


module.exports = router;

  