const express = require('express');
const router = express.Router();
const mysql = require('mysql');
const checkAuth = require('../middleware/check-atuh');

const multer = require('multer');
const path = require('path');
const storage = multer.diskStorage({
destination: function(req, file, cb){
  cb(null, './uploads');
},
filename: function(req, file, cb){
cb(null, file.originalname);
}
}); 

const fileFilter = (req, file, cb) => {
  
  if(file.mimetype === 'image/jpeg' || file.mimetype === 'image/png' || file.mimetype === 'image/jpeg'){

    cb(null, true);
  }else{

    cb(null, false);
  }
}


const upload = multer({
  storage: storage, 
  limits: {fileSize: 1024 * 1024 * 5},
  fileFilter: fileFilter

});

// MySQL connection (make sure to move this to a better place in your code, if you want to use it in different routes)
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'rsms',
});

db.connect((err) => {
  if (err) {
    console.error('Database connection failed:', err);
    return;
  }
  //console.log('Connected to MySQL database');
});


 

// New endpoint for profile or verification
router.get("/", checkAuth, (req, res) => {
  const query = 'SELECT * FROM basicinfo';

    db.query(query, (error, results) => {
        if (error) {
            console.error('Database query error:', error);
            return res.status(500).json({ error: 'Database query failed' });
        }
        res.json(results);
});




    //   res.status(200).json({
//     message: 'Handling GET requests to /students'
//   });
});
router.post('/', checkAuth, upload.single('image'), (req, res, next) => {
  console.log(req.file);

  const { admno, name, standard, monthly_fee, status, father, adm_date, adm_standard, mobile, address, email } = req.body;

  // Check if image is uploaded
  let imagePath = null;
  if (req.file) {
    imagePath = req.file.path;
  }

  const sql = 'INSERT INTO basicinfo (adm_no, name, standard, image, monthly_fee, status, father, adm_date, adm_standard, mobile, address, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
  db.query(sql, [admno, name, standard, imagePath, monthly_fee, status, father, adm_date, adm_standard, mobile, address, email], (err, result) => {
    if (err) {
      console.error('Error inserting student: ', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.status(201).json({ id: result.insertId, admno, name, standard }); // You may also want to return the imagePath if required
  });
});




// Handling GET by admno
router.get('/:admno', checkAuth, (req, res, next) => {
    const admno = req.params.admno;
  
    const query = 'SELECT * FROM basicinfo WHERE adm_no = ?';
    db.query(query, [admno], (error, results) => {
      if (error) {
        console.error('Database query error:', error);
        return res.status(500).json({ error: 'Database query failed' });
      }
      if (results.length === 0) {
        return res.status(404).json({ message: 'Student not found' });
      }
      res.json(results[0]);
    });
  });
  
  // Update record
  // Update record
  // Update record
router.patch('/:admno', checkAuth, upload.single('image'), (req, res, next) => {
  const admno = req.params.admno;
  const { name, standard, monthly_fee, status, father, adm_date, adm_standard, mobile, address, email } = req.body;

  // Start constructing the SQL query.
  let sql = 'UPDATE basicinfo SET updated_at = NOW()'; // Initialize with timestamp
  const updateValues = [];

  // Check if any of the fields are provided for update. 
  // If the field is provided, append it to the SQL query and the update values.
  if (name) {
      sql += ', name = ?';
      updateValues.push(name);
  }
  if (standard) {
      sql += ', standard = ?';
      updateValues.push(standard);
  }
  if (monthly_fee) {
      sql += ', monthly_fee = ?';
      updateValues.push(monthly_fee);
  }
  if (status) {
      sql += ', status = ?';
      updateValues.push(status);
  }
  if (father) {
      sql += ', father = ?';
      updateValues.push(father);
  }
  if (adm_date) {
      sql += ', adm_date = ?';
      updateValues.push(adm_date);
  }
  if (adm_standard) {
      sql += ', adm_standard = ?';
      updateValues.push(adm_standard);
  }
  if (mobile) {
      sql += ', mobile = ?';
      updateValues.push(mobile);
  }
  if (address) {
      sql += ', address = ?';
      updateValues.push(address);
  }
  if (email) {
      sql += ', email = ?';
      updateValues.push(email);
  }

  // Handling the image upload
  if (req.file) { // If a new image has been uploaded
      const imagePath = path.join('uploads', req.file.filename);
      sql += ', image = ?'; // Add image field to SQL query
      updateValues.push(imagePath); // Add new image path to the values
  }
  

  sql += ' WHERE adm_no = ?'; // Specify the record to update with WHERE clause
  updateValues.push(admno); // The adm_no to identify the record to update

  // Execute the query
  db.query(sql, updateValues, (err, result) => {
      if (err) {
          console.error('Error updating student:', err);
          return res.status(500).json({ error: 'Database error' });
      }
      if (result.affectedRows === 0) {
          return res.status(404).json({ message: 'Student not found' });
      }
      res.status(200).json({ message: 'Student updated successfully' });
  });
});
 



  
  // Delete record
  router.delete('/del/:admno', checkAuth, (req, res, next) => {
    const studentId = req.params.admno;
    console.log(`Delete request received for adm_no: ${studentId}`);
    
    const sql = 'DELETE FROM basicinfo WHERE adm_no = ?';
    db.query(sql, [studentId], (err, result) => {
      if (err) {
        console.error('Error deleting student: ', err);
        return res.status(500).json({ error: 'Database error' });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'No student found' });
      }
      res.status(200).json({ message: 'Student deleted successfully' });
    });
  });
  

  router.get('/classes', (req, res, next) => {
    const query = 'SELECT * FROM basicinfo';
    db.query(query, (error, results) => {
      if (error) {
        console.error('Database query error:', error);
        return res.status(500).json({ error: 'Database query failed' });
      }
      res.json(results);
    });
});




  module.exports = router;